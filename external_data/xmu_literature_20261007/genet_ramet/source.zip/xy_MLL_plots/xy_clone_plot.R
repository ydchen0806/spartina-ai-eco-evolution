######################################################
# Script written by Matthew B. Hamilton for:
# Mating portfolio and neutral mechanisms are primary causes of genet-ramet frequencies and 
# spatial distributions in smooth cordgrass (Spartina alterniflora) along salt marsh tidal gradients
# 
# Authors: Jewel Tomasula, Seamus Caslin, Gina M. Wimp, and Matthew B. Hamilton*
# Department of Biology, Georgetown University, 3700 O Street NW, Washington, D.C., USA,
# *Corresponding Author Email: hamiltm1@georgetown.edu
#
# Submitted to Frontiers in Genetics February, 2026
#
# Date last edited: 02/10/2026
######################################################

# Load rstudioapi package to be able to get directory of source file
library("rstudioapi")

# Set working directory to source file location
setwd(dirname(getActiveDocumentContext()$path)) 

# Check updated working directory
getwd() 

# script to plot clone identity on x-y axes, requires input file with x, y and clone identity columns.
# This version is for SALT transect data 

library(ggplot2)
library(readxl)

full.data <- read_excel("SALT transects patches x y MLL.xlsx")

# specific patch to use, change to work with different patches, also change output file name below
working.patch <- 'Red'

plot_data <- subset(full.data, patch == working.patch)
#title_string <- working.patch


x.axis.max.value <- max(plot_data$y)

y.axis.max.value = max(plot_data$x)

#x_string <- expression(paste("Distance from ", italic("S. patens"), " edge (meters)"))

ggplot(plot_data, aes(x=y, y=x, color=clone)) +
  scale_x_continuous(name = "y-coordinate (m)", breaks = c(1:x.axis.max.value), expand = c(0, 0.8)) +
  scale_y_continuous(name = "x-transect (m)", breaks = c(1:y.axis.max.value), expand = c(0, 0.3)) +
  geom_point(size=0, show.legend = FALSE) +
  geom_label(label = plot_data$clone, aes(fill =factor(clone)), color = "white", fontface="bold", label.padding = unit(0.5, "lines"), label.r = unit(0.75, "lines"), size = 4, show.legend = FALSE)+
  theme_bw()

# ggplot(plot_data, aes(x=y, y=x, color=clone)) +
#   ggtitle(title_string)+
#   scale_x_discrete(name = "y coordinate (m)", breaks = c(0,3,6,9,12,15,18), expand = c(0, 1.2))+
#   scale_y_discrete(name = "x transect (m)", limits = c("1","2","3","4"))+
#   geom_point(size=0, show.legend = FALSE)+
#   geom_label(label = plot_data$clone, aes(fill=factor(clone)), color = "white", fontface="bold", label.padding = unit(0.5, "lines"), label.r = unit(0.5, "lines"), size = 5, show.legend = FALSE)+
#   theme_bw()

