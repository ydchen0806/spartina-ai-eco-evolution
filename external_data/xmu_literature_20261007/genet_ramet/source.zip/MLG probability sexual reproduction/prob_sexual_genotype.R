######################################################
# Script written by Matthew B. Hamilton for:
# Mating portfolio and neutral mechanisms are primary causes of genet-ramet frequencies and 
# spatial distributions in smooth cordgrass (Spartina alterniflora) along salt marsh tidal gradients
# 
# Authors: Jewel Tomasula, Seamus Caslin, Gina M. Wimp, and Matthew B. Hamilton*
# Department of Biology, Georgetown University, 3700 O Street NW, Washington, D.C., USA,
# *Corresponding Author Email: hamiltm1@georgetown.edu
#
# Submitted to Frontiers in Genetics February, 2026
#
# Date last edited: 02/10/2026
######################################################

# Load rstudioapi package to be able to get directory of source file
library("rstudioapi")

setwd(dirname(getActiveDocumentContext()$path)) # Set working directory to source file location

getwd() # Check updated working directory

# RClone is a R package version of GenClone program (Arnaud-Haond & Belkhir 2007)
# package is no longer maintained on CRAN so need to load from archive
# https://www.rdocumentation.org/packages/RClone/versions/1.0.3
install.packages("RClone_1.0.3.tar.gz", repos = NULL, type = "source")

# look at vignette or manual
#vignette(package="RClone")
#vignette("RClone_quickmanual", package="RClone")

library(RClone)

# read in data set 
orig.genotype.data <- read.table("SALT_transect_all_genotypes.txt", sep="\t", header=TRUE)

# look at the header and top few lines of the data file
head(orig.genotype.data)

# determine number of loci in genotype data
n.loci <- ncol(orig.genotype.data)/2

#make a copy of the genotype data to modify
genotype.data <- orig.genotype.data


list <- which(genotype.data == 0, arr.ind=TRUE)

# Impute missing data
# for each locus, find zeros (or the missing value) and then replace them with alleles
# sampled at random from among the alleles in both columns for that locus. This "imputes" 
# missing data using alleles based on the observed allele frequencies
missing.value = 0

for (col in seq(from=1, to=(2*n.loci), by=2)) {
  
  #print(col)

  one_locus_alleles <- orig.genotype.data[,col:(col+1)]
  
  list <- which(one_locus_alleles == missing.value, arr.ind=TRUE)
  
  #print(list)
  
  replace.size <- as.numeric(length(one_locus_alleles[(one_locus_alleles == 0)]))
  
  #print(replace.size)
  
  if (replace.size != 0){
    # from alleles not equal zero sample two with replacement
    new_alleles <- sample(one_locus_alleles[!(one_locus_alleles == 0)], replace.size, replace = T)
    
    genotype.data[,col:(col+1)] <- replace(one_locus_alleles, list, new_alleles)
  }
}

# check to be sure that all zeros were detected and replaced
#list <- which(genotype.data == 0, arr.ind=TRUE)

# save the imputed genotype data to tab delimited text file if you want
write.table(genotype.data, "SALT_transect_all_genotypes_imputed_missing.txt", append = FALSE, sep = "\t", dec = ".", row.names = FALSE, col.names = TRUE)

# see https://www.rdocumentation.org/packages/RClone/versions/1.0.3
#vignette("RClone_quickmanual")

# make a data table to summarize the alleles at each locus
list_all_tab(genotype.data)

# make a table showing the multilocus genotypes - could take a while to compute
MLG_tab(genotype.data)

# make allele frequency table, round-robin estimation method
freq_RR(genotype.data, RR = TRUE) #on ramets

# 
MLLlist <- MLL_generator(genotype.data, manh = TRUE)


genet_result <- psex(genotype.data, genet = TRUE) # psex on genets, gives the expected genotype frequency of each genet under psex assumptions
plot(genet_result, main='Expected frequency of each genet multilocus genotype\nunder sexual reproduction & random mating', xlab='Genet', ylab='Expected frequency')

# compute the probability that repeated genotypes originate from distinct sexual events (i.e. being different genets and not ramets of the same MLG) assuming H-W equilibrium
table <- psex(genotype.data, RR = TRUE, nbrepeat = 100, bar = TRUE) # with p-values and a progress bar

# display the results table

table[[1]]

# save the genotype probabilities to tab delimited text file
write.csv(table[[1]], "SALT_transect_all_genotypes_psex_random_mating.csv", row.names = FALSE)


# compute the probability that repeated genotypes originate from distinct sexual events (i.e. being different genets and not ramets of the same MLG) assuming adjusting for Fis
# *** this is slow to execute ***
table_Fisadj <- psex_Fis(genotype.data, RR = TRUE, nbrepeat = 100, bar = TRUE) # with p-values and a progress bar

# display the results table
table_Fisadj[[1]]

# save the genotype probabilities to tab delimited text file
write.csv(table_Fisadj[[1]], "SALT_transect_all_genotypes_psex_Fisadj.csv",row.names = FALSE)

# make a scatter plot of the MLG probabilities for each genet
plot(table_Fisadj[[1]]$genet, table_Fisadj[[1]]$psexFis, xlim = c(1, 935), ylim = c(0, 0.0001), main='Expected frequency of each genet multilocus genotype\n under sexual reproduction (fixation-index adjusted)', xlab='genet', ylab='prob identical MLG with sexual reproduction')


# make a histogram of the MLG probabilities for each genet
# remove any rows that are blank (the ramets)
psex <- table_Fisadj[[1]] [(! table_Fisadj[[1]]$psexFis==""), ]

class(psex$psexFis)
psex_num <- as.numeric(psex$psexFis)

hist(psex_num, breaks=40, xlim=c(0,0.000000001), ylim=c(0,500), main='Distribution of probabilities of identical MLG for each genet \n (round-robin allele frequencies, fixation-index adjusted genotype freqs)', xlab='Probability of multilocus genotype (MLG)', ylab='Count of genets')

length(psex_num)


# use 10 loci from simulated clonal population data set
data(popsim)

#genetic distances computation, distance on allele differences:
respop <- genet_dist(popsim)

ressim <- genet_dist_sim(popsim, nbrepeat = 1000) #theoretical distribution:
#sexual reproduction
ressimWS <- genet_dist_sim(popsim, genet = TRUE, nbrepeat = 1000) #idem, without selfing
#graph prep.:
p1 <- hist(respop$distance_matrix, freq = FALSE, col = rgb(0,0.4,1,1), main = "popsim", xlab = "Genetic distances", breaks = seq(0, max(respop$distance_matrix)+1, 1))

p2 <- hist(ressim$distance_matrix, freq = FALSE, col = rgb(0.7,0.9,1,0.5), main = "popSR", xlab = "Genetic distances", breaks = seq(0, max(ressim$distance_matrix)+1, 1))

p3 <- hist(ressimWS$distance_matrix, freq = FALSE, col = rgb(0.9,0.5,1,0.3), main = "popSRWS", xlab = "Genetic distances",
           breaks = seq(0, max(ressimWS$distance_matrix)+1, 1))

