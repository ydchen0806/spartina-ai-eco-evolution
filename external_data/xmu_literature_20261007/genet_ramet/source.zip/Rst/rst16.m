function rst
% program to calculate Rst estimator of Fst based on microsatellite data.
% Includes bootstrap significance testing where resampling is across POPULATIONS

% version 1.6 02/01/2004
% allelic state can be zero, includes weightings for loci, tallies observed
% heterozygosity, computes Rst among all pairs of populations,
% randomization CI for Rst among all pairs of populations (fixed effects hypothesis test) 

% Contains code to compute BOTH the ratio of the sum of variances and the average of the ratios
% of variances for multilocus Rst (see Balloux & Goudet 2002 Mecular Ecology 11:771-783)

% input:
% program expects an Excel file with ...
% 1st row: number of loci; comment
% 2nd row: number of populations; comment
% 3rd row: title of dataset
% 4th row: locus names
% 5th row: name of 1st population
% numeric data starts in 6th row, 5 rows down
% Population names must contain at least one character so that they are NAN.
% Each population must contain at least one individual with non-missing data at each locus.
% See file "rstexample.xls" for an example of the file format.

% Declare variables
rawmissingvalue=-9;       %value of <=rawmissingvalue is considered missing data in original data file, should be <zero
stdmissingvalue=-100;    %value of <=stdmissingvalue is considered missing data in standardized data file
bootreps = 5000;    %number of bootstrap replicates, must use at least one
randomizereps = 5000;    %number of randomizations for null distribution of Rst for pairs of pops, must use at least one
sigalpha = 0.05;    %significance level for confidence intervals, provides (1-sigalpha)% CI

doWeights = 0;  %switch for weighted average of variance components, 0=skip 1=do calculation
% weights is a 1 by nloci vector of weights used to weight loci in calculating multilocus Rho
%weights = [1,0.5,0.5,0.5,0.5,0.25,0.25,0.25,0.25,1,0.1667,0.1667,0.1667,0.1667,0.1667,0.1667,0.5,0.5,1,1,1,1,1];
weights = [1,1,1,1,1,1,1,1,1,1];

% End declare variables
%rstexample.xls 
%Msax10loci final.xls
inFile = 'SALT_transects_MLLs_for_Rst.xlsx';    %name of the input Excel file
%outFile = 'rst_output.txt';   %name of tab delimited text file for output

[data, labels] = xlsread(inFile);    %open the file and read in data, get numeric data and text data separately
%parse input file for genotypes and alphanumeric data
[nloci,npops,genotypes,popsizes,popindices,rows,cols] = getdata(data,labels);
allelesperlocus = 2*rows;

% get observed heterozygosity (Ho) for genotype data
Ho=zeros(nloci,1);   %observed heterozygosity per locus, allocate space
[Ho] = getHo(genotypes,cols,rows,rawmissingvalue);   %1 by nloci vector of observed heterozygosities for each locus
Ho

% make new genotype matrix
% put data into matrix with one column of alleles per locus
[colgenotypes,colpopindices]=reDimenData(allelesperlocus,nloci,npops,popindices,genotypes,popsizes);

% standardize allele sizes to zero mean and unit variance for each locus
[stdgenotypes]=standardizeAlleleData(colgenotypes,nloci,allelesperlocus,rawmissingvalue,stdmissingvalue);

% calculate single locus Rst and the various version of multilocus Rst
[slRho,mlRSTu,mlRSTw,WmlRSTu,WmlRSTw]=calcRst(stdgenotypes,nloci,allelesperlocus,npops,popsizes,colpopindices,doWeights,weights,stdmissingvalue);
slRho   %print Rst values for each locus
mlRSTw  %print multilocus Rst based on ratio of the sum of variances across loci
%netallelesperlocus = (2*repmat(popsizes,[1,nloci]))-perpopmissing; %alleles per locus minus missing data

% bootstrap across populations
pops = (1:npops);    %row vector of all populations in sample
pops=pops';          %col vector of all populations in sample
for y=1:bootreps
    [rstdpop,rpopindices,rpopsizes,rallelesperlocus] = resamplepops(nloci,npops,pops,stdgenotypes,colpopindices,popsizes); %sample with replacement from all populations in sample 
    %stdgenotypes
    %rstdpop
        
    [rslRho(y,:),rmlRSTu(y),rmlRSTw(y),rWmlRSTu(y),rWmlRSTw(y)]=calcRst(rstdpop,nloci,rallelesperlocus,npops,rpopsizes,rpopindices,doWeights,weights,stdmissingvalue);

end

[SingleLocusRstLowerCIbounds(:,1), SingleLocusRstUpperCIbounds(:,1)] = bootconfint(rslRho',sigalpha,bootreps)
[MLRstLowerCIbounds(:,1), MLRstUpperCIbounds(:,1)] = bootconfint(rmlRSTw,sigalpha,bootreps)
if (doWeights == 1)
    [WeightedMLRstLowerCIbounds(:,1), WeightedMLRstUpperCIbounds(:,1)] = bootconfint(rWmlRSTw,sigalpha,bootreps)
end

%plot histrogram of resampled Fst estimates used for CI
figure(1);
bins = -0.1:0.05:1.1;
hist(rmlRSTw(1,:), bins);
title('distribution of bootstrap (populations resampled) multilocus Rst(w) estimates'); 
xlabel('bootstrap mlRst value');
ylabel('frequency');


% estimate Rst among all pairs of populations
disp('Rst among all pairs of populations')
rows=2*popsizes;  %double number of individuals since there are two alleles per individual
ncomparisons = (npops*(npops-1))/2;  %number of unique pairwise comparions
PWnpops=2;

PWmlRSTu=zeros(npops,npops);    %allacate space
PWmlRSTu(:,:)=nan;              %fill with nan

PWWmlRSTw=zeros(npops,npops);  %allacate space
PWWmlRSTw(:,:)=nan;            %fill with nan

PWmlLowbds=zeros(npops,npops);  %allacate space
PWmlLowbds(:,:)=nan;            %fill with nan

PWmlUpbds=zeros(npops,npops);  %allacate space
PWmlUpbds(:,:)=nan;            %fill with nan

for i=1:npops
    for j=i+1:npops
       
        %stdgenotypes
        %stdpopindices
        tempgenotypes(1:rows(i,1),:) = stdgenotypes(colpopindices(i,1):colpopindices(i,2),:);
        startrow = rows(i,1)+1;
        endrow = rows(i,1)+rows(j,1);
        tempgenotypes(startrow:endrow,:) = stdgenotypes(colpopindices(j,1):colpopindices(j,2),:);
        
        PWpopsizes(1,1)=popsizes(i,1);  %make pairwise column vector of popsizes
        PWpopsizes(2,1)=popsizes(j,1);
        
        PWpopindices(1,1)=1;
        PWpopindices(1,2)=rows(i,1);
        PWpopindices(2,1)=startrow;
        PWpopindices(2,2)=endrow;
        
        PWpopsizes(1,1)=popsizes(i,1);
        PWpopsizes(2,1)=popsizes(j,1);
        
        PWallelesperlocus = endrow; %num of alleles in TOTAL temp dataset
        
        % calculate single locus Rst and the various versions of multilocus Rst
        [slRho,PWmlRSTu(i,j),PWmlRSTw(i,j),PWWmlRSTu(i,j),PWWmlRSTw(i,j)]=calcRst(tempgenotypes,nloci,...
            PWallelesperlocus,PWnpops,PWpopsizes,PWpopindices,doWeights,weights,stdmissingvalue);        
        
        % randomization test for Rst among all pairs of populations
        % randomly assign individuals to two populations and determine 95% CI for Rst
        % this is equivalent to a fixed effect hypothesis test for Rst of the population pair being different than random mixing
        for k=1:randomizereps
            PWnIndividuals=PWpopsizes(1,1)+PWpopsizes(2,1);
            index=randperm(PWallelesperlocus);  % get random set of npops indices
		    randtempgenotypes=tempgenotypes(index,:); % assign individuals to pops based on indices, or individuals among pops
            %tempgenotypes
            [RandslRho,RandPWmlRSTu(1,k),RandPWmlRSTw(1,k),RandPWWmlRSTu(1,k),RandPWWmlRSTw(1,k)]=calcRst(randtempgenotypes,nloci,...
                PWallelesperlocus,PWnpops,PWpopsizes,PWpopindices,doWeights,weights,stdmissingvalue);        

        end
        [PWmlLowbds(i,j),PWmlUpbds(i,j)]=bootconfint(RandPWmlRSTu, sigalpha, randomizereps);
    end
end

disp('matrices of multilocus Rst among all pairs of populations (rows and column nums are pop nums)');
disp('multilocus Rst for all pairs of populations');
PWmlRSTu
if (doWeights == 1)
    disp('WEIGHTED multilocus Rst for all pairs of populations');
    PWWmlRSTw
end

disp('matrices of upper and lower confidence bounds from randomization of individuals');
disp('lower bounds');
PWmlLowbds
disp('upper bounds');
PWmlUpbds


%_______________________________________
function[slRho,mlRSTu,mlRSTw,WmlRSTu,WmlRSTw]=calcRst(genotypes,nloci,allelesperlocus,npops,popsizes,colpopindices,doWeights,weights,missingvalue);
% actually compute rho or Rst

%outputs:
% SingleLocusRho: Rst for each locus (1 by nloci)
% mlRSTu: multilocus Rst as the average of the of the ratio of variances across loci
% mlRSTw: multilocus Rst as ratio of the sum of variances across loci
% WmlRSTu: weighted multilocus Rst as the average of the of the ratio of variances across loci
% WmlRSTw: weighted Rst as ratio of the sum of variances across loci


%get mean and variance for each locus of standardized data, should be mean=0 and var = 1, but will check
stdmeans=zeros(nloci,1);   %mean allelic state per locus for total population, allocate space
stdmissing=zeros(nloci,1);   %number of missing alleles per locus, allocate space
svar=zeros(nloci,2);   %variance and SD of standardized allelic state per locus for total population, allocate space
[stdmeans,stdmissing]=getmean(genotypes, nloci, allelesperlocus, missingvalue);
[svar]=getvariance(genotypes, stdmeans, nloci, allelesperlocus, missingvalue);

%get within population variance
swvar=zeros(nloci,npops);   %variance of standardized allelic state per locus within each population, allocate space
stdmeanswp=zeros(nloci,npops);   %mean allelic state per locus within populations, allocate space
perpopmissing=zeros(nloci,npops);
[swvar, stdmeanswp, perpopmissing]=withinpopvar(genotypes,colpopindices,npops,nloci,popsizes,missingvalue);

% get between population variance according to Goodman 1997
stdmeans=stdmeans';  %transpose so dimens are 1 by nloci
stdmeanswp=stdmeanswp'; %transpose so dimens are npops by nloci
perpopmissing=perpopmissing';   %transpose so dimens are npops by nloci
netallelesperlocus = (2*repmat(popsizes,[1,nloci]))-perpopmissing; %alleles per locus minus missing data
mlstdmeans = repmat(stdmeans,[npops,1]);

squaredDiff = (stdmeanswp-mlstdmeans).^2;
Sbsquared = netallelesperlocus.*squaredDiff;  %nd x (ybar-ydoublebar) within each pop for each locus
MSb = sum(Sbsquared,1)/(npops-1);    %sum across pops for each locus and div npops-1
no = (1/(npops-1))*( (sum(netallelesperlocus,1)-( sum(netallelesperlocus.^2,1)/(sum(netallelesperlocus,1) ) ) ) );
mlnpops=repmat(npops,[1,nloci]);
swvar=swvar';    %transpose so dimens are npops by nloci
eplisonMSw = (no./mlnpops).*sum(swvar./netallelesperlocus,1);
sigmasquaredB = (MSb-eplisonMSw)./no;

swvarbar=zeros(1,nloci);  %average within pop variances in std allelic state, allocate space
swvarbar=(sum(swvar,1))./npops;

%get single locus Rho
slRho = sigmasquaredB./(sigmasquaredB+swvarbar);   % single locus estimates of Rst, eqn. 4 of Goodman 1997

%get multilocus RST
sigmasquaredB = sum(sigmasquaredB,2);
mlavgsigmasquaredB = sigmasquaredB/nloci;
wvarbar = sum(swvarbar,2);
mlavgswvarbar = wvarbar/nloci;

%See Balloux and Goudet.  2002.  Molecular Ecology 11:771-783.
% average of the of the ratio of variances across loci
mlRSTu = mlavgsigmasquaredB/(mlavgsigmasquaredB+mlavgswvarbar);

% ratio of the sum of variances across loci
mlRSTw = sigmasquaredB/(sigmasquaredB + wvarbar);

%get weighted multi locus Rho
if (doWeights == 1)
		WsigmasquaredB = sum(weights.*sigmasquaredB,2);
		WmlavgsigmasquaredB = WsigmasquaredB/nloci;
        
		Wwvarbar = sum(weights.*swvarbar,2);
		Wmlavgswvarbar = Wwvarbar/nloci;

        WmlRSTu = WmlavgsigmasquaredB/(WmlavgsigmasquaredB+Wmlavgswvarbar);
        WmlRSTw = WsigmasquaredB/(WsigmasquaredB + Wwvarbar);
else
    %'skipped weighted multilocus Rho calculation (WmlRSTu & WmlRSTw set to nan)'
    WmlRSTu = nan;
    WmlRSTw = nan;
end

%_______________________________________
function[colgenotypes,colpopindices]=reDimenData(allelesperlocus,nloci,npops,popindices,genotypes,popsizes);
% input: genotype data matrix where alleles for each lous are in two columns
% output: data matrix with one column of alleles per locus
%   colgenotypes: n individuals by nloci matrix
%   colpopindices: npops by 2 matrix of indices for data for each pop 
%       (e.g. colpopindices(1,:) contains 1, 20 meaning that data from
%       population 1 is in rows 1 through 20)

colpopindices=zeros(npops,2);    %allocate space
%allelesperlocus = 2*rows;
colgenotypes = zeros(allelesperlocus,nloci);   %allocate space
for x=1:npops
    countcol=0;
	for i=1:nloci
        if x==1
            countrow=1;
            
        else
            countrow=2*(sum(popsizes(1:x-1)))+1;
        end
        colpopindices(x,1) = countrow;
            
        for j=1:2
            countcol=countcol+1;
            for k=(sum(popsizes(1:x-1),1)+1):(sum(popsizes(1:x),1))
                %k
                colgenotypes(countrow, i) = genotypes(k, countcol);
                countrow=countrow+1;
            end
            colpopindices(x,2) = countrow-1;
        end
	end
end
% colgenotypes
% popindices
% colpopindices

%_______________________________________
function[stdgenotypes]=standardizeAlleleData(colgenotypes,nloci,allelesperlocus,rawmissingvalue,stdmissingvalue);
% input: genotype data matrix with one column of alleles per locus
% output: genotype data matrix with allele sizes standardized to zero mean and unit variance for each locus

% for raw data missing values are <0
% get mean allelic state per locus for raw data
[totmeans,missing]=getmean(colgenotypes,nloci,allelesperlocus,rawmissingvalue);
%totmeans

% get var and SD in allelic state per locus for raw data
[totvars]=getvariance(colgenotypes,totmeans,nloci,allelesperlocus,rawmissingvalue);
%totvars

%standardize allelic values for each locus
for i=1:nloci
    for j=1:allelesperlocus
        if (colgenotypes(j,i)>=0)
            stdgenotypes(j,i) = (colgenotypes(j,i)-totmeans(i,1))/totvars(i,2); %z=(yi-ybar)/SD Goodman eqn. 3
        else
            stdgenotypes(j,i) = stdmissingvalue;   %set missing to this value since will not be able to use <0 anymore
        end
    end
end
%stdgenotypes

%_______________________________________
function[nloci,npops,genotypes,popsizes,popindices,rows,cols] = getdata(data,labels);    %parse file for genotypes and other data
% input: an Excel file with:
% 1st row: number of loci; comment
% 2nd row: number of populations; comment
% 3rd row: title of dataset
% 4th row: locus names
% 5th row: name of 1st population
% numeric data starts in 6th row, 5 rows down
% each population is separated by one line with the population name in the left-most cell
% Population names must contain at least one character so that they are NAN.
% Each population must contain at least one individual with non-missing data at each locus.

nloci = data(1,1);   %number of loci, top left cell
npops = data(2,1);   %number of populations, one cell below top left cell

%calculate individual population sizes
start = 6;                  %numerical values always start on 6th row
popsizes = zeros(npops,1);  %allocate space
popindices = zeros(npops,2);    %allocate space
vec = isnan(data(:,1));     %get vector of 0 = non-nan, 1 = nan, p. 160 of Hanselman
maxindex = size(vec,1);

vec(maxindex+1,1)=1;    %cram an extra 1 for nan into last cell since it is lacking
maxindex = maxindex+1;  %increment maxindex by one

counter=0;
pop=1;
for i=6:maxindex
    % count rows until encountering a value of 1 (equal to nan).  
    % NANs are population name fields that separate population data blocks.
    if (vec(i,1) == 1)
        popsizes(pop,1) = counter;
        popindices(pop,2)=i-1;  %last row of data for this pop
        popindices(pop,1)=i-counter;  %first row of data for this pop
        counter=0;
        pop=pop+1;
    else
        counter=counter+1;
    end
end
% popsizes
% popindices

% now need to get JUST numerical data into a matrix
rows = sum(popsizes,1); %sum down column
cols = 2*nloci;  %total number of allele entries, 2 per locus
genotypes = zeros(rows,cols);   %allocate space

counter=1;
for i=1:npops
    for j=popindices(i,1):1:popindices(i,2)
        genotypes(counter,:) = data(j,:);
        counter=counter+1;
    end
end
%genotypes

%_______________________________________
function [pairwiseRst, wpairwiseRst] = estimatePairwiseRst(nloci,npops,stdgenotypes,stdpopindices,popsizes,stdmissingvalue,doWeights,weights)
% estimate Rst for each pair of populations using standardized data

%inputs:
% nloci = number of loci
% npops = number of populations
% stdgenotypes = a npop by nloci matrix of standardized allele values (all alleles are in one column for each locus)
% stdpopindices = a npop by 2 matrix of the rows for the beginning (col 1) and end (col 2) of each population
% popsizes = number of individuals within each population (npops x 1 vector)

%popsizes 
rows=2*popsizes;  %double number of individuals since there are two alleles per individual
ncomparisons = (npops*(npops-1))/2;  %number of unique pairwise comparions
PWnpops=2;

for i=1:npops
    for j=i+1:npops
        %stdgenotypes
        %stdpopindices
        tempgenotypes(1:rows(i,1), :) = stdgenotypes(stdpopindices(i,1):stdpopindices(i,2), :);
        startrow = rows(i,1)+1;
        endrow = rows(i,1)+rows(j,1);
        tempgenotypes(startrow:endrow, :) = stdgenotypes(stdpopindices(j,1):stdpopindices(j,2), :);
        
        PWpopsizes(1,1)=popsizes(i,1);  %make pairwise column vector of popsizes
        PWpopsizes(2,1)=popsizes(j,1);
        
        PWpopindices(1,1)=1;
        PWpopindices(1,2)=rows(i,1);
        PWpopindices(2,1)=startrow;
        PWpopindices(2,2)=endrow;
        
        PWpopsizes(1,1)=popsizes(i,1);
        PWpopsizes(2,1)=popsizes(j,1);
        
        PWallelesperlocus = endrow; %num of alleles in TOTAL temp dataset
        
        %get mean and variance for each locus of standardized data, should be mean=0 and var = 1, but will check
		%stdmeans=zeros(nloci,1);   %mean allelic state per locus for total population, allocate space
		%stdmissing=zeros(nloci,1);   %number of missing alleles per locus, allocate space
		%svar=zeros(nloci,2)   %variance and SD of standardized allelic state per locus for total population, allocate space
		[stdmeans,stdmissing]=getmean(tempgenotypes, nloci, PWallelesperlocus, stdmissingvalue);
		[svar]=getvariance(tempgenotypes, stdmeans, nloci, PWallelesperlocus, stdmissingvalue);
        
		%get within population variance
		swvar=zeros(nloci,PWnpops);   %variance of standardized allelic state per locus within each population, allocate space
		stdmeanswp=zeros(nloci,PWnpops);   %mean allelic state per locus within populations, allocate space
		perpopmissing=zeros(nloci,PWnpops);
		
		[swvar, stdmeanswp, perpopmissing]=withinpopvar(tempgenotypes,PWpopindices,PWnpops,nloci,PWpopsizes,stdmissingvalue);
		
		% get between population variance according to Goodman 1997
        
		stdmeans=stdmeans';  %transpose so dimens are 1 by nloci
		stdmeanswp=stdmeanswp'; %transpose so dimens are PWnpops by nloci
		perpopmissing=perpopmissing';   %transpose so dimens are PWnpops by nloci
		allelesperlocus = (2*repmat(PWpopsizes,[1,nloci]))-perpopmissing; %alleles per locus minus missing data
		mlstdmeans = repmat(stdmeans,[PWnpops,1]);
		
		squaredDiff = (stdmeanswp-mlstdmeans).^2;
		Sbsquared = allelesperlocus.*squaredDiff;  %nd x (ybar-ydoublebar) within each pop for each locus
		MSb = sum(Sbsquared,1)/(PWnpops-1);    %sum across pops for each locus and div PWnpops-1
		no = (1/(PWnpops-1))*( (sum(allelesperlocus,1)-( sum(allelesperlocus.^2,1)/(sum(allelesperlocus,1) ) ) ) );
		mlnpops=repmat(PWnpops,[1,nloci]);
		swvar=swvar';    %transpose so dimens are PWnpops by nloci
		eplisonMSw = (no./mlnpops).*sum(swvar./allelesperlocus,1);
		sigmasquaredB = (MSb-eplisonMSw)./no;
		
		swvarbar=zeros(1,nloci);  %average within pop variances in std allelic state, allocate space
		swvarbar=(sum(swvar,1))./PWnpops;
		
		%get single locus Rho
		SingleLocusRho = sigmasquaredB./(sigmasquaredB+swvarbar);   % eqn. 4 of Goodman 1997
		
		%get multilocus RST
		sigmasquaredB = sum(sigmasquaredB,2);
		mlavgsigmasquaredB = sigmasquaredB/nloci;
		wvarbar = sum(swvarbar,2);
		mlavgswvarbar = wvarbar/nloci;
		
		%See Balloux and Goudet.  2002.  Molecular Ecology 11:771-783.
		% average of the of the ratio of variances across loci
		mlRSTu = mlavgsigmasquaredB/(mlavgsigmasquaredB+mlavgswvarbar);
		
		% ratio of the sum of variances across loci
		mlRSTw = sigmasquaredB/(sigmasquaredB + wvarbar);
		
		%get weighted multi locus Rho
		if (doWeights == 1)
    		WsigmasquaredB = sum(weights.*sigmasquaredB,2);
			WmlavgsigmasquaredB = WsigmasquaredB/nloci;
            
			Wwvarbar = sum(weights.*swvarbar,2);
			Wmlavgswvarbar = Wwvarbar/nloci;

            WmlRSTu = WmlavgsigmasquaredB/(WmlavgsigmasquaredB+Wmlavgswvarbar);
            WmlRSTw = WsigmasquaredB/(WsigmasquaredB + Wwvarbar);

        end

    end
end

pairwiseRst=MultilocusRho;
if (doWeights == 1)
    wpairwiseRst=WeightedMultilocusRho;
else
    wpairwiseRst=nan;
end

%_______________________________________
function [rstdpop,rpopindices,rpopsizes,rallelesperlocus] = resamplepops(nloci,npops,pops,stdgenotypes,stdpopindices,popsizes)
%resample populations with replacement for bootstrap
%test to see if resampled pops are all the same population, if so resample again
%cannot assume anything about uniformity of pop size

%inputs:
%npops = the number of populations sampled
%pops = the row vector of indices of sampled populations
%stdgenotypes = a npop by nloci matrix of standardized allele values (all
%               alleles are in one column for each locus)
%stdpopindices = a npop by 2 matrix of the rows for the beginning (col 1) and end (col 2) of each population

    %get a sample with replacement
    dup=1;
    while dup==1
		index = unidrnd(npops,1,npops); % get random set of npops indices
        mx=max(index);   %get first index of maximum value
        i=find(index==mx);   %get all other indices that are equal to maximum value
        numdups = length(i);   %get size of array of indices that are equal to max
        if numdups==npops
            dup=1;  %all pops are the same
        else
            dup=0;  %all pops are not the same
        end
    end
    
    index=index';   %make index a column vector
    temppopindices=stdpopindices(index,:);
    rpopsizes = popsizes(index,:);
    %MLallelesperlocus= (2*repmat(popsizes,[1,nloci]))-perpopmissing; %alleles per locus minus missing data
    %rallelesperlocus = allelesperlocus(index,:)
    
    rrows=sum(rpopsizes,1); %resampled total individuals (sum down column)
    rallelesperlocus = 2*rrows; %resampled total alleles (twice num of individuals)
    rstpop=zeros(rrows,nloci);  %allocate space
    startrow=1;
    for i=1:npops
        %startrow
        span=2*rpopsizes(i);
        rstdpop(startrow:startrow+span-1,:) = stdgenotypes(temppopindices(i,1):temppopindices(i,2),:);
        
        rpopindices(i,1)=startrow;  %start for resampled pop i
        rpopindices(i,2)=startrow+span-1;  %end for resampled pop i
        
        startrow=startrow+span;
    end
    %rpopindices

%________________________
function [swvar, stdmeanswp, perpopmissing]=withinpopvar(stdgenotypes,stdpopindices,npops,nloci,popsizes,stdmissingvalue);
%get within population variance
tempswvar=zeros(npops,2);   %variance and SD of standardized allelic state per locus within each population, allocate space
%swvar=zeros(nloci,npops);   %variance of standardized allelic state per locus within each population, allocate space
%stdmeanswp=zeros(nloci,npops);   %mean allelic state per locus within populations, allocate space
%perpopmissing=zeros(nloci,npops);
for i=1:npops
    subdata = stdgenotypes(stdpopindices(i,1):stdpopindices(i,2),:);
    [stdmeanswp(:,i),perpopmissing(:,i)]=getmean(subdata, nloci, 2*popsizes(i,1), stdmissingvalue);
    %stdmeanswp
    [tempswvar]=getvariance(subdata, stdmeanswp(:,i), nloci, 2*popsizes(i,1), stdmissingvalue);
    %ttempswvar=tempswvar';
    swvar(:,i)=tempswvar(:,1);
end
%swvar
%________________________
function [means,nmissing]=getmean(datamatrix, cols, rows, missingval);
%sum to get mean, BUT must skip missing data
%missing data are values <= missingval
%returns means per locus and missing per locus
%means are 1 by nloci
for i=1:cols
    sum=0;
    miss=0;
    for j=1:rows
        if (datamatrix(j,i)>missingval)
            sum=sum+datamatrix(j,i);
        else
            miss=miss+1;
        end
    end
    means(i,1) = sum/(rows-miss);
    nmissing(i,1)=miss;
end
%________________________
function [var]=getvariance(datamatrix, means, cols, rows, missingval);
%get variance, BUT must skip missing data (so can't use var function easily!)
%missing data are values <= missingval
%var is cols (nloci) by 2
%returns variance (col 1) and SD (col 2) of allelic state per locus
for i=1:cols
    ssd=0;
    missing=0;
    for j=1:rows
        if (datamatrix(j,i)>missingval)
            ssd=ssd+(datamatrix(j,i)-means(i,1))^2;
        else
            missing=missing+1;
        end
    end
    var(i,1) = ssd/(rows-missing-1);    %var = ssd/n-1
    var(i,2) = sqrt(var(i,1));          %SD = sqrt(var)
end
%_______________________________________
function [Ho]=getHo(datamatrix, cols, rows, missingval);
%get observed heterozygosity, BUT must skip missing data
%missing data are values <= missingval
%Ho is a row vector 1 by nloci
locus=0;
for i=1:2:cols
    locus=locus+1;  %count locus we are on
    numgenotypes=0; %counter for num non-missing genotypes per locus
    CountHo=0;
    for j=1:rows
        if (datamatrix(j,i)>missingval)
            if (datamatrix(j,i)~=datamatrix(j,i+1)) %compare the two alleles for one genotype
                CountHo=CountHo+1;
            end
            numgenotypes=numgenotypes+1;    %increment counter for non-missing genotypes
        end
       
    end
    %numgenotypes
    %CountHo
    Ho(1,locus) = CountHo/numgenotypes; %observed heterozygosity is proprotion of non-missing genotypes which are heterozygotes
    %i
    %locus
end
%_______________________________________
function [bootlowbds, bootupbds]=bootconfint(thetareps, alpha, numreps)
% makes bootstrap confidence interval
% inputs:
% thetareps = vector or array of point estimates from bootstrap procedure
% dimensions: (locus, replicate estimate)
% (may be output of bootdip.m or boothap.m)
% alpha: request (1-alpha) confidence interval
% outputs:
% [bootlowbds, bootupbds] = lower and upper bounds on confidence interval
% dimensions: (locus) 

%numreps=length(thetareps);
% length of confindence interval
intlength = min(round((1-alpha)*numreps),numreps);

% find best confidence interval
% note: for now, we find the SHORTEST INTERVAL in absolute terms.
numloci=size(thetareps);
numloci=numloci(1);

for locus=1:numloci % find CI for each locus separately
thetareps(locus,:)=sort(thetareps(locus,:));
bootlowbd=1;
bootupbd=intlength;
confwidth=thetareps(locus,bootupbd)-thetareps(locus,bootlowbd);
for i=2:numreps-intlength+1
    testwidth=thetareps(locus,i+intlength-1)-thetareps(locus,i);
    if testwidth<confwidth
        confwidth=testwidth;
        bootupbd=i+intlength-1;
        bootlowbd=i;
    end
end

% convert indices to confidence limits
bootlowbds(locus)=thetareps(locus,bootlowbd);
bootupbds(locus)=thetareps(locus,bootupbd);
end

% make column vectors
bootlowbds=bootlowbds.';
bootupbds=bootupbds.';  
%_______________________________________