######################################################
# Script written by Matthew B. Hamilton for:
# Mating portfolio and neutral mechanisms are primary causes of genet-ramet frequencies and 
# spatial distributions in smooth cordgrass (Spartina alterniflora) along salt marsh tidal gradients
# 
# Authors: Jewel Tomasula, Seamus Caslin, Gina M. Wimp, and Matthew B. Hamilton*
# Department of Biology, Georgetown University, 3700 O Street NW, Washington, D.C., USA,
# *Corresponding Author Email: hamiltm1@georgetown.edu
#
# Submitted to Frontiers in Genetics February, 2026
#
# Date last edited: 02/10/2026
######################################################

# script to carry out Mantel test for isolation by distance

# Load rstudioapi package to be able to get directory of source file
library("rstudioapi")

setwd(dirname(getActiveDocumentContext()$path)) # Set working directory to source file location

getwd() # Check updated working directory

library(vegan)

library(ade4)

# input data; change file name for each patch such as SALT_Blue_MLL_distances.txt etc
SALT.patch.df <- read.table("SALT_Yellow_MLL_distances.txt", header = TRUE)

unique_MLLs <- unique(SALT.patch.df$MLL2)

n_MLLs <- length(unique_MLLs) + 1

genetic_matrix <- matrix(0, nrow = n_MLLs, ncol = n_MLLs)

row_entry <- 1
for (i in 1:n_MLLs) {
  for (j in i:n_MLLs) {
    
    if (i == j) {
      genetic_matrix[i,j] <- 0
    } else {
        genetic_matrix[i,j] <- SALT.patch.df$Bruvos_dist[row_entry]
        
        genetic_matrix[j,i] <- SALT.patch.df$Bruvos_dist[row_entry]
        
        row_entry <- row_entry + 1
    }
    
  }
}


geodist_matrix <- matrix(0, nrow = n_MLLs, ncol = n_MLLs)

row_entry <- 1
for (i in 1:n_MLLs) {
  for (j in i:n_MLLs) {
    
    if (i == j) {
      geodist_matrix[i,j] <- 0
    } else {
      geodist_matrix[i,j] <- SALT.patch.df$eucl_dist[row_entry]
      
      geodist_matrix[j,i] <- SALT.patch.df$eucl_dist[row_entry]
      
      row_entry <- row_entry + 1
    }
    
  }
}

# # make matrices into distances
genetic.dists <- as.dist(genetic_matrix)

geodist.dists <- as.dist(geodist_matrix)


# Mantel test in vegan package
mantel(genetic.dists, geodist.dists, method = "spearman", permutations = 9999)


# Mantel test in ade4 package
mantel.rtest(genetic.dists, geodist.dists, nrepet = 9999)

