######################################################
# Script written by Matthew B. Hamilton for:
# Mating portfolio and neutral mechanisms are primary causes of genet-ramet frequencies and 
# spatial distributions in smooth cordgrass (Spartina alterniflora) along salt marsh tidal gradients
# 
# Authors: Jewel Tomasula, Seamus Caslin, Gina M. Wimp, and Matthew B. Hamilton*
# Department of Biology, Georgetown University, 3700 O Street NW, Washington, D.C., USA,
# *Corresponding Author Email: hamiltm1@georgetown.edu
#
# Submitted to Frontiers in Genetics February, 2026
#
# Date last edited: 02/10/2026
######################################################

# Load rstudioapi package to be able to get directory of source file
library("rstudioapi")

# Set working directory to source file location
setwd(dirname(getActiveDocumentContext()$path)) 

# Check updated working directory
getwd() 

# get all pairs of distances between points defined by latitude and longitude

# use geosphere package
#install.packages("geosphere")

library(geosphere)

coordinates <- read.csv("Transect coordinates.csv")

n.patches <- nrow(coordinates)

dist.matrix <- matrix(0, nrow = n.patches, ncol = n.patches)


for (r in 1:n.patches) {
  for (c in 1:r) {
    
    point1 <- coordinates[r, c(2:3)]
    point2 <- coordinates[c, c(2:3)]
    
    distance <- distHaversine(point1, point2) # Returns distance between points in meters
    
    dist.matrix[r,c] <- distance
    dist.matrix[c,r] <- distance
    
    #print(r)
    #print(c)
    #print(distance)
  }
}

print(dist.matrix)

# write lower triangular matrix to file
write.table(dist.matrix, file = "/Users/mathewhamilton/Library/CloudStorage/Dropbox/SALT Tomasula transect data/isolation by distance/SALT_patch_pairwise_m_distances_matrix.txt", sep = "\t", row.names = FALSE, col.names = FALSE)



# Define the number of rows and columns
num_rows <- (n.patches*(n.patches-1))/2
num_cols <- 3
column_names <- c("pop1", "pop2", "dist(m)")

# Create a matrix of zeros and convert it to a data frame
zero_matrix <- matrix(0, nrow = num_rows, ncol = num_cols)
dist.table <- as.data.frame(zero_matrix)

# Assign column names
colnames(dist.table) <- column_names

row <- 1 # initialize counter

for (r in 1:n.patches) {
  for (c in 1:r) {
    
    point1 <- coordinates[r, c(2:3)]
    dist.table[row,1] <- coordinates[r, 1]
    
    point2 <- coordinates[c, c(2:3)]
    dist.table[row,2] <- coordinates[c, 1]
    
    distance <- distHaversine(point1, point2) # Returns distance between points in meters
    
    dist.table[row,3] <- distance
    
    row <- row + 1 # increment row counter
  }
}

# Print the data frame
print(dist.table)

# write lower triangular matrix to file
write.table(dist.table, file = "SALT_patch_pairwise_m_distances_table.txt", sep = "\t", row.names = FALSE, col.names = FALSE)

