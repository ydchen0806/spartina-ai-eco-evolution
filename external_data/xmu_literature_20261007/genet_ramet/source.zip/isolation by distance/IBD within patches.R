######################################################
# Script written by Matthew B. Hamilton for:
# Mating portfolio and neutral mechanisms are primary causes of genet-ramet frequencies and 
# spatial distributions in smooth cordgrass (Spartina alterniflora) along salt marsh tidal gradients
# 
# Authors: Jewel Tomasula, Seamus Caslin, Gina M. Wimp, and Matthew B. Hamilton*
# Department of Biology, Georgetown University, 3700 O Street NW, Washington, D.C., USA,
# *Corresponding Author Email: hamiltm1@georgetown.edu
#
# Submitted to Frontiers in Genetics February, 2026
#
# Date last edited: 02/10/2026
######################################################

# Load rstudioapi package to be able to get directory of source file
library("rstudioapi")

# Set working directory to source file location
setwd(dirname(getActiveDocumentContext()$path)) 

# Check updated working directory
getwd() 


library(ggplot2)

# Set your working directory to the folder containing the distance files for each patch
setwd("./combined distance files for all patches/")

# Get a list of all file names with the ".txt" extension
file_list <- list.files(pattern = "*.txt", full.names = TRUE)

# Read each file into a list of data frames using lapply
data_list <- lapply(file_list, read.table, header = TRUE)

# Combine all the data frames in the list into a single data frame using do.call and rbind
combined_data_files <- do.call(rbind, data_list)

# View the first few rows of the combined data
head(combined_data_files)

#combined_data_files$patch <- as.factor(patch)

# regression for Bruvo's genetic distance and distance in meters
bruvos.dist.fit <- glm(Bruvos_dist ~ eucl_dist, family=gaussian(link="identity"), data=combined_data_files)
summary(bruvos.dist.fit)

bruvos.dist.fit.patch <- glm(Bruvos_dist ~ eucl_dist + as.factor(patch), family=gaussian(link="identity"), data=combined_data_files)
summary(bruvos.dist.fit.patch)


# generate plot

my_colors <- c("Blue"="blue", "Yellow"="gold", "Brown"="brown", "Green"='green', "Black"="black", "Gray"="gray", "Orange"="orange", "Pink"="pink", "Purple"="purple", "Red"="red")

ggplot(combined_data_files, aes(x = eucl_dist, y = Bruvos_dist, color = patch)) +
  theme_bw() +
  labs(
    x = "Geographic distance between MLL centroids (meters)",
    y = "Bruvo's genetic distance between MLL pairs within patches",
    #title = "Your Plot Title",
    #subtitle = "Your Plot Subtitle"
  ) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE) +
  scale_color_manual(values = my_colors) 


