######################################################
# Script written by Matthew B. Hamilton for:
# Mating portfolio and neutral mechanisms are primary causes of genet-ramet frequencies and 
# spatial distributions in smooth cordgrass (Spartina alterniflora) along salt marsh tidal gradients
# 
# Authors: Jewel Tomasula, Seamus Caslin, Gina M. Wimp, and Matthew B. Hamilton*
# Department of Biology, Georgetown University, 3700 O Street NW, Washington, D.C., USA,
# *Corresponding Author Email: hamiltm1@georgetown.edu
#
# Submitted to Frontiers in Genetics February, 2026
#
# Date last edited: 02/10/2026
######################################################

# Load rstudioapi package to be able to get directory of source file
library("rstudioapi")

# Set working directory to source file location
setwd(dirname(getActiveDocumentContext()$path)) 

# Check updated working directory
getwd() 

# script to fit regression to linearized Gst or Rst by distance between patches

library (readxl)

# input data
data <- read_excel("SALT_transects_dist_Gst_rst.xlsx", col_names=TRUE)


# regression for linearized Gst and distance in meters
gst.fit <- glm(linGst ~ distance,family=gaussian(link="identity"),data=data)
summary(gst.fit)

# regression for linearized Rst and distance in meters
rst.fit <- glm(linRst ~ distance,family=gaussian(link="identity"),data=data)
summary(rst.fit)




plot(data$distance, data$linGst, 
     pch = 16, col = "blue", 
     xlab = "Distance between patches (m)", 
     ylab = "Linearized genetic differentiation", 
     #main = "Scatter Plot with Two Y Variables",
     ylim = c(0, 1.0) ) # Set the Y-limit to encompass both datasets

# Add the first regression line (for y1)
model1 <- lm(data$linGst ~ data$distance)
abline(model1, col = "blue", lwd = 2)

# Add the second dataset as points to the existing plot
# par(new = TRUE) can be used for separate axes, but here we use points() for the same axis range
points(data$distance, data$linRst, 
       pch = 17, col = "red") # Use a different shape and color

# Add the second regression line (for y2)
model2 <- lm(data$linRst ~ data$distance)
abline(model2, col = "red", lwd = 2, lty = 2) # Dashed line for distinction


# Add a legend to differentiate the series
legend("topright", inset=.02,
       legend = c(expression("G''"[ST]), expression("R"[ST])), 
       col = c("blue", "red"), 
       pch = c(16, 17),
       lty = c(1, 2),
       lwd = 2 )

