######################################################
# Script written by Matthew B. Hamilton for:
# Mating portfolio and neutral mechanisms are primary causes of genet-ramet frequencies and 
# spatial distributions in smooth cordgrass (Spartina alterniflora) along salt marsh tidal gradients
# 
# Authors: Jewel Tomasula, Seamus Caslin, Gina M. Wimp, and Matthew B. Hamilton*
# Department of Biology, Georgetown University, 3700 O Street NW, Washington, D.C., USA,
# *Corresponding Author Email: hamiltm1@georgetown.edu
#
# Submitted to Frontiers in Genetics February, 2026
#
# Date last edited: 02/10/2026
######################################################

# Load rstudioapi package to be able to get directory of source file
library("rstudioapi")

# Set working directory to source file location
setwd(dirname(getActiveDocumentContext()$path)) 

# Check updated working directory
getwd() 

# Script to compute the geographic distance matrix using MLL centroids within patches
# Centroids for each MLL are computed using the mean x-y coordinates for all ramets for a given MLL

library (readxl)

# https://rdocumentation.org/packages/RecordLinkage/versions/0.4-12.5
library(RecordLinkage) # for unorderedPairs function


# path for desktop
full.data <- read_excel("SALT transects patches x y MLL.xlsx")

# path for laptop
#full.data <- read_excel("/Users/matthewhamilton/Dropbox/SALT Tomasula transect data/isolation by distance/SALT transects patches x y MLL.xlsx")

# set patch, change to work through all ten patches
working.patch <- 'Red'

outfilename <- "SALT_MLL_centroid_dists_Red.txt"

onepatch.df <- full.data[full.data$patch == working.patch, ]

# get unique MLL numbers in patch
MLL.list <- unique(onepatch.df$clone)

# get number of MLLs in patch
n.MLLs <- length(MLL.list)

# initialize new matrix for centroid x and y of each MLL
centroids <- matrix(NA, ncol = 3, nrow = n.MLLs)
colnames(centroids) <- c("MLL", "x", "y")

# get centroid for each MLL
for (i in 1:n.MLLs) {
  
  oneMLL.df <- onepatch.df[onepatch.df$clone == MLL.list[i], c(3,4)]

  n.points <- nrow(oneMLL.df)
  
  # MLL
  centroids[i, 1] <- i
  
  # mean of x coords
  centroids[i, 2] <- mean(oneMLL.df$x)
    
  # mean of y coords
  centroids[i, 3] <- mean(oneMLL.df$y)
  
}


# get x and y only
MLL.centroid.coords <- centroids[ , 2:3] 

# Calculate the pairwise distances
dist_object <- dist(MLL.centroid.coords, method = "euclidean")

# The 'dist_object' is already a vector under the hood, so access it directly
distance_values_vector <- as.vector(dist_object)

distance.values.df <- as.data.frame(distance_values_vector)

# Print the vector of values
#print(distance_values_vector)

# get two columns giving all unordered MLL pairs
n.uordered.pairs <- (n.MLLs*(n.MLLs-1))/2

MLL.pairs <- matrix(0, ncol = 2, nrow = n.uordered.pairs)

counter <- 1

for (i in 1:(n.MLLs-1)) {
  for (j in (i+1):n.MLLs) {
    
    MLL.pairs[counter,1] <- MLL.list[i]
    
    MLL.pairs[counter,2] <- MLL.list[j]
    
    counter <- counter + 1
  }
  
}

MLL.pairs <- as.data.frame(MLL.pairs)

patch.MLL.distances <- cbind(MLL.pairs,distance.values.df)

colnames(patch.MLL.distances) <- c("MLL1", "MLL2", "eucl_distance")


# write to file
write.table(patch.MLL.distances, file = outfilename, sep = "\t", row.names = FALSE, col.names = TRUE)

