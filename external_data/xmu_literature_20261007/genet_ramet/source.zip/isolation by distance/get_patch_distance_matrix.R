######################################################
# Script written by Matthew B. Hamilton for:
# Mating portfolio and neutral mechanisms are primary causes of genet-ramet frequencies and 
# spatial distributions in smooth cordgrass (Spartina alterniflora) along salt marsh tidal gradients
# 
# Authors: Jewel Tomasula, Seamus Caslin, Gina M. Wimp, and Matthew B. Hamilton*
# Department of Biology, Georgetown University, 3700 O Street NW, Washington, D.C., USA,
# *Corresponding Author Email: hamiltm1@georgetown.edu
#
# Submitted to Frontiers in Genetics February, 2026
#
# Date last edited: 02/10/2026
######################################################

# Load rstudioapi package to be able to get directory of source file
library("rstudioapi")

# Set working directory to source file location
setwd(dirname(getActiveDocumentContext()$path)) 

# Check updated working directory
getwd() 

# Script to compute the geographic distance matrix for each patch based on its x-y coordinate grid

library (readxl)

install.packages("usedist")
library(usedist)


full.data <- read_excel("SALT transects patches x y MLL.xlsx")

# set working patch, change name for other patches
working.patch <- 'Blue'

onepatch.df <- full.data[full.data$patch == working.patch, ]

# get columns 'x', 'y'
patch.coords.df <- onepatch.df[ , c(3,4)]

# Set the 'clone' column as the row names
#rownames(patch.coords.df) <- onepatch.df$clone

# Calculate the Euclidean distance matrix (returns lower triangular)
distance_matrix <- dist(patch.coords.df, method = "euclidean")

# Add clone identities as row and column names if desired
#distance_matrix <- dist_setNames(distance_matrix, nm = onepatch.df$clone)

# print the distance matrix
print(distance_matrix)

# write lower triangular matrix to file
write.table(distance_matrix, file = "Blue_Euclid_lowertri_dist_matrix.txt", sep = "\t", row.names = FALSE, col.names = FALSE)


# convert to a square matrix
square.distance.matrix <- as.matrix(distance_matrix) # To see it as a standard matrix

# write lower triangular matrix to file
write.table(square.distance.matrix, file = "Blue_Euclid_dist_matrix.txt", sep = "\t", row.names = FALSE, col.names = FALSE)



n.MLLs <- max(onepatch.df[5])

centroids <- matrix(NA, ncol = 2, nrow = n.MLLs)

mll.coords.df <- onepatch.df[onepatch.df$clone==1, c(3,4)]

centroids[1,1] = mean(mll.coords.df$x)
centroids[1,2] = mean(mll.coords.df$y)

library(geosphere)
# Assuming 'points' is a matrix or dataframe of your coordinates
centroid.1<- centroid(mll.coords.df)


# define MLL as groups and get distance between centroid of MLLs
centroid.dists <- dist_to_centroids(distance_matrix, onepatch.df[5], squared = FALSE) 

# print the centroid groups distance matrix
print(centroid.dists)


# Arguments d g squared 
# 
# Details 
# Adistance matrix object of class dist. 
# Afactor representing the groups of items in d. 
# If TRUE, return the squared distance to group centroids.


# Sample data with groups
pts <- data.frame(
  x = c(-1, 0, 0, 1, 2, 3, 3, 4),
  y = c(0, 1, -1, 0, 0, 1, -1, 0),
  Item = LETTERS[1:8],
  Group = rep(c("Control", "Treatment"), each=4)
)

# Create a distance matrix (e.g., Euclidean distance)
pts_matrix <- dist(pts[, c("x", "y")])

# Calculate distance of each item to its group centroid
dist_to_centroids(pts_matrix, pts$Group)
