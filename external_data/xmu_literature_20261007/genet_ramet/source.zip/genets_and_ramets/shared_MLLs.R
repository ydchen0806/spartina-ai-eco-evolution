######################################################
# Script written by Matthew B. Hamilton for:
# Mating portfolio and neutral mechanisms are primary causes of genet-ramet frequencies and 
# spatial distributions in smooth cordgrass (Spartina alterniflora) along salt marsh tidal gradients
# 
# Authors: Jewel Tomasula, Seamus Caslin, Gina M. Wimp, and Matthew B. Hamilton*
# Department of Biology, Georgetown University, 3700 O Street NW, Washington, D.C., USA,
# *Corresponding Author Email: hamiltm1@georgetown.edu
#
# Submitted to Frontiers in Genetics February, 2026
#
# Date last edited: 02/10/2026
######################################################

# Load rstudioapi package to be able to get directory of source file
library("rstudioapi")

# Set working directory to source file location
setwd(dirname(getActiveDocumentContext()$path)) 

# Check updated working directory
getwd() 

# script to read in file with populations and MLLs and then find the MLLs that are common to each pair of populations

library(readxl)

# data for all MLLs (or genets or clones) from all 10 patches in a single file
SALT.MLLs <- read_xlsx("SALT_transect_ten_ID_pop_MLLs_threshold_8.xlsx")

summary(SALT.MLLs)

n.pops <- max(SALT.MLLs$Population)

for (i in 1:(n.pops-1)) {
  for (j in (i+1):n.pops) {
    # find the ramet count categories that are > min_ramet_count
    one.pop <- SALT.MLLs[SALT.MLLs$Population == i, ]
    other.pop <- SALT.MLLs[SALT.MLLs$Population == (j), ]
    
    # Find the overlapping integers
    overlap <- intersect(one.pop$clone, other.pop$clone)
    
    # Print the result
    print(i)
    print(j)
    print(overlap)
  }
}

