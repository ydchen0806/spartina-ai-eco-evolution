######################################################
# Script written by Matthew B. Hamilton for:
# Mating portfolio and neutral mechanisms are primary causes of genet-ramet frequencies and 
# spatial distributions in smooth cordgrass (Spartina alterniflora) along salt marsh tidal gradients
# 
# Authors: Jewel Tomasula, Seamus Caslin, Gina M. Wimp, and Matthew B. Hamilton*
# Department of Biology, Georgetown University, 3700 O Street NW, Washington, D.C., USA,
# *Corresponding Author Email: hamiltm1@georgetown.edu
#
# Submitted to Frontiers in Genetics February, 2026
#
# Date last edited: 02/10/2026
######################################################

# Load rstudioapi package to be able to get directory of source file
library("rstudioapi")

# Set working directory to source file location
setwd(dirname(getActiveDocumentContext()$path)) 

# Check updated working directory
getwd() 

# script to get summary descriptive counts and statistics from ramets per MLL counts for all patches

# path for desktop
SALT.total.pop <- read.csv("SALT_ramet_per_genet.csv")

summary(SALT.total.pop)

# N = total number of observations in the data set
N <- sum(SALT.total.pop[,"obs.genets"])

n_patches <- max(SALT.total.pop[ ,"pop"])

# get version of data with only observed genets great than zero
#SALT.total.pop.no.zeros <- SALT.total.pop[SALT.total.pop$obs.genets > 0, ]

# get MLL counts weighted by number of ramets
#w_MLL_count <- SALT.total.pop.no.zeros[ ,"ramet.count"]*SALT.total.pop.no.zeros[ ,"obs.genets"]

#mean.area <- sum(w_MLL_count)/N
  



# maxrows = number of rows in the data set
maxrows <- dim(SALT.total.pop)[1]

# salt.df = data frame structure to store and organize data
salt.df <- data.frame(y=rep(-1,N), pop=rep(-1,N))

cntr <- 0
J <- 1
while(J<=maxrows) {
  cat("J = ",J,"\n")
  nreps <- SALT.total.pop[J,"obs.genets"]
  cat("nreps = ",nreps,"\n")
  if(nreps>0) { # skip rows that have 0 obs., otw do ...
    ids <- (cntr+1):(cntr+nreps) # rows in the new data set that are filled with new data
    salt.df$y[ids] <- rep(SALT.total.pop[J,"ramet.count"],nreps) # counts
    salt.df$pop[ids] <- rep(SALT.total.pop[J,"pop"],nreps) # population ID
  }
  
  J <- J+1 # increment row counter in Excel spreadsheet
  cntr <- cntr + nreps # increment row counter in new data frame
}

table(salt.df$y) # <-- some numbers do not exactly match the combined 'single popn' data set

# salt.df$y is counts of ramets for each MLL, always > 0

summary(salt.df$y)

t.test(salt.df$y)

# get only those rows where observed ramets per genet > one
salt.y.twoplus <- salt.df[salt.df$y > 1, ]

summary(salt.y.twoplus$y)

t.test(salt.y.twoplus$y)

# Get means, medians, t.test and CIs for each patch for all ramet counts and counts > 1
result_by_patch <- aggregate(y ~ pop, data = salt.y.twoplus, FUN = median)

# Print the result
print(result_by_patch)

for (i in 1:n_patches) {
  
  one.patch <- salt.y.twoplus[salt.y.twoplus$pop == i, ]
  
  print(t.test(one.patch$y))
  
}

