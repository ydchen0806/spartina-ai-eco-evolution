######################################################
# Script written by Matthew B. Hamilton and Brent A. Johnson for:
# Mating portfolio and neutral mechanisms are primary causes of genet-ramet frequencies and 
# spatial distributions in smooth cordgrass (Spartina alterniflora) along salt marsh tidal gradients
# 
# Authors: Jewel Tomasula, Seamus Caslin, Gina M. Wimp, and Matthew B. Hamilton*
# Department of Biology, Georgetown University, 3700 O Street NW, Washington, D.C., USA,
# *Corresponding Author Email: hamiltm1@georgetown.edu
#
# Submitted to Frontiers in Genetics February, 2026
#
# Date last edited: 02/10/2026
######################################################

# Script to re-format ramets per MLL into individual counts, then run zero-truncated negative binomial regressions,
# and then generate plots using model predicted and observed counts
# see https://stats.oarc.ucla.edu/r/dae/zero-truncated-negative-binomial/


# Load rstudioapi package to be able to get directory of source file
library("rstudioapi")

# Set working directory to source file location
setwd(dirname(getActiveDocumentContext()$path)) 

# Check updated working directory
getwd() 

require(ggplot2)
require(VGAM) # package contains a function for zero-truncated Poisson family
#require(pscl)
#require(boot)
require(AER) # package contains a test of the dispersion parameter in GLMs


# path for desktop
SALT.total.pop <- read.csv("SALT_ramet_per_genet.csv")

summary(SALT.total.pop)

# plot count data
ggplot(SALT.total.pop, aes(x=ramet.count, y=obs.genets)) + geom_point() + theme_bw()


# N = total number of observations in the data set
N <- sum(SALT.total.pop[,"obs.genets"])

# maxrows = number of rows in the Excel spreadsheet from which to pull data
maxrows <- dim(SALT.total.pop)[1]

# salt.df = data frame structure to store and organize data
salt.df <- data.frame(y=rep(-1,N),
                      pop=rep(-1,N))

cntr <- 0
J <- 1
while(J<=maxrows) {
  cat("J = ",J,"\n")
  nreps <- SALT.total.pop[J,"obs.genets"]
  cat("nreps = ",nreps,"\n")
  if(nreps>0) { # skip rows that have 0 obs., otw do ...
    ids <- (cntr+1):(cntr+nreps) # rows in the new data set that are filled with new data
    salt.df$y[ids] <- rep(SALT.total.pop[J,"ramet.count"],nreps) # counts
    salt.df$pop[ids] <- rep(SALT.total.pop[J,"pop"],nreps) # population ID
  }
  
  J <- J+1 # increment row counter in Excel spreadsheet
  cntr <- cntr + nreps # increment row counter in new data frame
}

table(salt.df$y) # <-- some numbers do not exactly match the combined 'single popn' data set

# get only those rows where observed genets > zero
SALT.total.pop.nonzero <- SALT.total.pop[SALT.total.pop$obs.genets > 0, ]

# zero-truncated Poisson with a rate for each patch, better for MLL/ramet data since zero observation not possible
ft.ztP.byPatch <- vglm(obs.genets ~ -1 + as.factor(pop),family=pospoisson(),data=SALT.total.pop.nonzero) # zero-truncated Poisson
summary(ft.ztP.byPatch)

# Extract the rate coefficients for later use in plotting
coefficients_matrix <- coefvlm(ft.ztP.byPatch, matrix = TRUE)

# Calculate incidence rate ratio (IRR) by computing e^coefficient and 95% CI IRR
exp(cbind(OR = coef(ft.ztP.byPatch), confint(ft.ztP.byPatch)))

yhat.ft.ztP.byPatch <- predict(ft.ztP.byPatch)
resid.ft.ztP.byPatch <- SALT.total.pop.nonzero$obs.genets - yhat.ft.ztP.byPatch
plot(yhat.ft.ztP.byPatch, resid.ft.ztP.byPatch, ylab="Residuals",xlab="Predicted Values")



# zero-truncated Poisson with a rate for each patch, better for MLL/ramet data since zero observation not possible
ft.ztNB.byPatch <- vglm(y~as.factor(pop),family=posnegbinomial,data=salt.df) # zero-truncated Poisson
summary(ft.ztNB.byPatch)

# Extract the rate coefficients for later use in plotting
coefficients_matrix_NB_patch <- coefvlm(ft.ztNB.byPatch, matrix = TRUE)

# Calculate incidence rate ratio (IRR) by computing e^coefficient and 95% CI IRR
#exp(cbind(OR = coef(ft.ztP.byPatch), confint(ft.ztP.byPatch)))


yhat.ft.ztNB.byPatch <- predict(ft.ztNB.byPatch)
resid.ft.ztNB.byPatch <- salt.df$y - yhat.ft.ztNB.byPatch
plot(yhat.ft.ztNB.byPatch, resid.ft.ztNB.byPatch, ylab="Residuals",xlab="Predicted Values")

# # save predicted values for plotting
# salt.plus.predicted.df <- cbind(salt.df, yhat.ft.ztP.byPatch)
# colnames(salt.plus.predicted.df)[3] <- "ypredicted"

# now fit as one population without a rate for each patch
ft.ztNB.onepop <- vglm(y~1,family=posnegbinomial,data=salt.df) # zero-truncated Poisson
summary(ft.ztNB.onepop)
# take -2x difference in log likelihood (chi-sq dist) df=difference in df of the two models
# -2*(-878.763 -1117.092) = 3991.71 with 225-216 = 9 df


yhat.ft.ztNB.onepop <- predict(ft.ztNB.onepop)
resid.yhat.ft.ztNB.onepop <- salt.df$y - yhat.ft.ztNB.onepop
plot(yhat.ft.ztNB.onepop, resid.yhat.ft.ztNB.onepop, ylab="Residuals", xlab="Predicted Values")

# Extract the rate coefficients for later use in plotting
coefficients_matrix_NB_onepop <- coefvlm(ft.ztNB.onepop, matrix = TRUE)




#get version of data without the three largest MLLs that have 37, 47 and 101 ramets
salt.trimmed.df <- salt.df[salt.df$y<37, ]

# fit the zero-truncated Poisson with one rate for each patch without large, extreme values ...
#ft3.noo <- vglm(y~-1+as.factor(pop),family=pospoisson(),data=salt.df,subset=y<37)
ft.ztP.byPatch.trim <- vglm(y~-1+as.factor(pop),family=pospoisson(),data=salt.trimmed.df)
summary(ft.ztP.byPatch.trim)

# now fit as one population without a rate for each patch
ft.ztP.onepop.trim <- vglm(y~1,family=pospoisson(),data=salt.trimmed.df) # zero-truncated Poisson
summary(ft.ztP.onepop.trim)

# take -2x difference in log likelihood (chi-sq dist) df=difference in df of the two models
# -2*(-650.7397 -741.47) =  with 222-213 = 9 df



yhat.ft.ztP.byPatch.trim <- predict(ft.ztP.byPatch.trim)
resid.ft.ztP.byPatch.trim <- salt.trimmed.df$y - yhat.ft.ztP.byPatch.trim
plot(yhat.ft.ztP.byPatch.trim, resid.ft.ztP.byPatch.trim, ylab="Residuals", xlab="Predicted Values")



# zero-trucated negative binomial, which allows for over-dispersed count data
#ft4 <- vglm(y~as.factor(pop),family=posnegbinomial(),data=salt.df) # zero-truncated negative binomial --> 34 warnings





# Plot ramets per MLL for each patch
# plus a line through the predicted values

max.ramet.count <- 101

y.axis.max.value <- 30

plot_B <- plot(SALT.total.pop$ramet.count[SALT.total.pop$pop==1],SALT.total.pop$obs.genets[SALT.total.pop$pop==1],type="n", ylim=c(0,y.axis.max.value), xlim=c(1,max.ramet.count+1), xaxt="n",
               xlab="Ramets per MLL", ylab="MLL count") 

axis(1,at=c(1:max.ramet.count+1))

for (J in 2:10) {
  points(SALT.total.pop$ramet.count[SALT.total.pop$pop==J],SALT.total.pop$obs.genets[SALT.total.pop$pop==J],pch=J,cex=0.5,col=J)
  
  lines(SALT.total.pop$ramet.count[SALT.total.pop$pop==J],SALT.total.pop$pred.genets[SALT.total.pop$pop==J],col=J)
}


legend("topright", inset=.02,
       legend=c("Blue", "Gray","Pink","Purple","Orange","Red","Green","Yellow","Brown","Black"),
       pch = c(1:10), lty= c(1:10), col = c(1:10), cex=0.9, pt.cex = 1
)


# Poisson density plot from Google search on "r plot of zero truncated poisson density given rate"

# Define the rate (lambda)
# lambda <- 0.774

# Define the zero-truncated Poisson PMF function
# p(x) = (e^-lambda * lambda^x) / (x! * (1 - e^-lambda)) for x = 1, 2, ...
dztpois <- function(x, lambda) {
  if (any(x <= 0)) warning("x values must be positive integers for ZTP distribution")
  # Use dpois for standard Poisson PMF
  # Denominator (1 - P(X=0)) is 1 - dpois(0, lambda)
  # prob <- dpois(x, lambda) / (1 - dpois(0, lambda))
  
  prob <- dgaitdpois(x,lambda,truncate = 0)
  
  return(prob)
}

patches <- 10
max_ramet_count <- 101
ztp_fitted_values <- matrix(data = 0, nrow = patches*max_ramet_count, ncol = 4)
total_MLLs <- matrix(data = 0, nrow = patches, ncol = 1)

# get observed MLLs per ramet count for each patch, put in df for graph
# also get the total count of MLLs in each patch
start_row <- 1
for (i in 1:patches) {
  
  # get vector of observed MLL counts (varies in length)
  vec.obs <- SALT.total.pop$obs.genets[SALT.total.pop$pop==i]
  
  n_obs <- length(vec.obs)
  
  ztp_fitted_values[start_row:(start_row + n_obs - 1), 4] <- vec.obs
  
  total_MLLs[i] <- SALT.total.pop$rev.cum.count[SALT.total.pop$pop==i][1]
  
  start_row <- start_row + max_ramet_count
}

# Generate x values (positive integers only) to plot
# The distribution has support for x = 1, 2, ...
x_values <- 1:max_ramet_count # Adjust the upper limit as needed

# Calculate the ztP probabilities for each x value in each plot
start_row <- 1
stop_row <- max_ramet_count
for (i in 1:patches) {
  
  ztp_fitted_values[start_row:stop_row, 1] <- i
  
  ztp_fitted_values[start_row:stop_row, 2] <- x_values
  
  # 10 patches estimated coefficients are in coefficients_matrix
  ztp_fitted_values[start_row:stop_row, 3] <- dztpois(x_values, coefficients_matrix[i])
  
  # multiply each probability by the integer count of MLLs in the patch
  ztp_fitted_values[start_row:stop_row, 3] <- ztp_fitted_values[start_row:stop_row, 3]*total_MLLs[i]
  
  start_row <- start_row + max_ramet_count
  stop_row <- stop_row + max_ramet_count
}


# Calculate the ZTP probabilities for each x value
#ztp_probs <- dztpois(x_values, lambda)

# Create a data frame of the x and fitted values for ggplot2
ztp_data <- data.frame(ztp_fitted_values)

# Assign new names to all columns
colnames(ztp_data) <- c("patch", "ramet_count", "yhat", "yobs")






#Order of patches in data for rtP regressions (pop 1 through 10):
# legend=c("Blue","Gray","Pink","Purple","Orange","Red","Green","Yellow","Brown","Black")


# plot in two panels
#par(mfrow=c(2,1))

# plot patches with max ramets per MLL of 26
panel.A.patches <- c(1:5,7:9)

A_colors <- c("Blue"="blue","Gray"="gray","Pink"="pink","Purple"="purple","Orange"="orange","Green"="green","Yellow"="gold","Brown"="brown")

y.axis.max.value <- 30
x.axis.max.value <- 26

plot(ztp_data$ramet_count[ztp_data$patch==1], ztp_data$yobs[ztp_data$patch==1],type="n", ylim=c(0,y.axis.max.value), 
               xlim=c(0,x.axis.max.value), xaxt="n", xlab="Ramets per MLL", ylab="MLL count") 

axis(1, at=c(1:x.axis.max.value)) 

for (J in 1:8) {
  
  patch.number <- panel.A.patches[J]
  
  # points are observed counts
  points(ztp_data$ramet_count[ztp_data$patch==patch.number], ztp_data$yobs[ztp_data$patch==patch.number], pch=panel.A.patches[J], cex=0.8, col = A_colors[J])
  
  # lines are regression estimated rate fitted counts
  lines(ztp_data$ramet_count[ztp_data$patch==patch.number], ztp_data$yhat[ztp_data$patch==patch.number], col = A_colors[J])
}

legend("topright", inset=.02,
       legend=c("Blue","Gray","Pink","Purple","Orange","Green","Yellow","Brown"),
       pch = panel.A.patches, lty= 1, col = A_colors, cex=0.8, pt.cex = 1
)




B_colors <- c("Red"="red", "Black"="black")

panel.B.patches <- c(6,10)

y.axis.max.value <- 9
x.axis.max.value <- 101

plot(ztp_data$ramet_count[ztp_data$patch==6], ztp_data$yobs[ztp_data$patch==6],type="n", ylim=c(0,y.axis.max.value), 
               xlim=c(0,x.axis.max.value), xaxt="n", xlab="Ramets per MLL", ylab="MLL count") 

axis(1, at=c(1:x.axis.max.value)) 

for (J in 1:2) {
  
  patch.number <- panel.B.patches[J]
  
  # points are observed counts
  points(ztp_data$ramet_count[ztp_data$patch==patch.number], ztp_data$yobs[ztp_data$patch==patch.number], pch= panel.B.patches[J], cex=0.8, col = B_colors[J])
  
  # lines are regression estimated rate fitted counts
  lines(ztp_data$ramet_count[ztp_data$patch==patch.number], ztp_data$yhat[ztp_data$patch==patch.number], col = B_colors[J])
}

legend("topright", inset=.02,
       legend=c("Red","Black"),
       pch = panel.B.patches, lty= 1, col = B_colors, cex=0.8, pt.cex = 1
)

